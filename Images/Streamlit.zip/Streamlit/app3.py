import streamlit as st

st.link_button("Go to Google", "https://www.google.com")